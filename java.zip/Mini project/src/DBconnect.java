import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * A simple test class to verify Java and MySQL connectivity.
 */
public class DBconnect {

    // Database connection details
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/test";
    private static final String USER = "root";
    private static final String PASS = "";

    public static void main(String[] args) {
        Connection conn = null;

        try {
            // Register the JDBC driver
            Class.forName(JDBC_DRIVER);

            System.out.println("Connecting to database...");
            // Establish the connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("✅ Connected Successfully!");

        } catch (SQLException se) {
            // Handle errors for JDBC
            System.err.println("Database connection failed!");
            se.printStackTrace();
        } catch (Exception e) {
            // Handle other errors
            System.err.println("An unexpected error occurred!");
            e.printStackTrace();
        } finally {
            // Finally block to close the connection
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se2) {
                se2.printStackTrace();
            }
        }
    }
}